﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnPizza = New System.Windows.Forms.Button()
        Me.btnStarters = New System.Windows.Forms.Button()
        Me.panPizza = New System.Windows.Forms.Panel()
        Me.btnSeafood = New System.Windows.Forms.Button()
        Me.btnTandooriexpress = New System.Windows.Forms.Button()
        Me.btnVegetarianhot = New System.Windows.Forms.Button()
        Me.btnBeefeater = New System.Windows.Forms.Button()
        Me.btnAmericanhot = New System.Windows.Forms.Button()
        Me.btnMeatfeast = New System.Windows.Forms.Button()
        Me.btnMediterraneanspecial = New System.Windows.Forms.Button()
        Me.btnHampineapple = New System.Windows.Forms.Button()
        Me.btnCheesetomato = New System.Windows.Forms.Button()
        Me.btnMargherita = New System.Windows.Forms.Button()
        Me.btnDesserts = New System.Windows.Forms.Button()
        Me.btnDrinks = New System.Windows.Forms.Button()
        Me.btnBurgerSalads = New System.Windows.Forms.Button()
        Me.panStarters = New System.Windows.Forms.Panel()
        Me.btnGarlicmushroombread = New System.Windows.Forms.Button()
        Me.btnChickenspringroll = New System.Windows.Forms.Button()
        Me.btnBBQchickenwings = New System.Windows.Forms.Button()
        Me.btnVegetarianspringrolls = New System.Windows.Forms.Button()
        Me.btnSpicychickenwings = New System.Windows.Forms.Button()
        Me.btnChickennuggets = New System.Windows.Forms.Button()
        Me.btnChips = New System.Windows.Forms.Button()
        Me.btnPotatowedges = New System.Windows.Forms.Button()
        Me.btnOnionrings = New System.Windows.Forms.Button()
        Me.btnGarlicbread = New System.Windows.Forms.Button()
        Me.panDesserts = New System.Windows.Forms.Panel()
        Me.bntChokiesCream = New System.Windows.Forms.Button()
        Me.btnPineapplefritter = New System.Windows.Forms.Button()
        Me.btnBelgianchocolate = New System.Windows.Forms.Button()
        Me.btnBananafritter = New System.Windows.Forms.Button()
        Me.btnStrawberry = New System.Windows.Forms.Button()
        Me.btnStrawberrycake = New System.Windows.Forms.Button()
        Me.btnHaaganDazs = New System.Windows.Forms.Button()
        Me.btnVanilla = New System.Windows.Forms.Button()
        Me.btnTennesseecake = New System.Windows.Forms.Button()
        Me.btnChocolateCake = New System.Windows.Forms.Button()
        Me.panDrinks = New System.Windows.Forms.Panel()
        Me.btnCans = New System.Windows.Forms.Button()
        Me.btnPureapplejuice = New System.Windows.Forms.Button()
        Me.btnPureorangejuice = New System.Windows.Forms.Button()
        Me.btnChocolate = New System.Windows.Forms.Button()
        Me.btnCappuccino = New System.Windows.Forms.Button()
        Me.btnRegulartea = New System.Windows.Forms.Button()
        Me.btnBottle = New System.Windows.Forms.Button()
        Me.btnRegularcoffe = New System.Windows.Forms.Button()
        Me.panBurgerSalad = New System.Windows.Forms.Panel()
        Me.btnMixedgreen = New System.Windows.Forms.Button()
        Me.btnChickenburger = New System.Windows.Forms.Button()
        Me.btnFishburger = New System.Windows.Forms.Button()
        Me.btnVegetableburger = New System.Windows.Forms.Button()
        Me.btnQuarterpounder = New System.Windows.Forms.Button()
        Me.btnHumus = New System.Windows.Forms.Button()
        Me.btnFreshsalad = New System.Windows.Forms.Button()
        Me.btnColeslaw = New System.Windows.Forms.Button()
        Me.panSize = New System.Windows.Forms.Panel()
        Me.btn15XL = New System.Windows.Forms.Button()
        Me.btn9M = New System.Windows.Forms.Button()
        Me.btn12L = New System.Windows.Forms.Button()
        Me.btn18XXL = New System.Windows.Forms.Button()
        Me.btnCoke = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.btnPepsi = New System.Windows.Forms.Button()
        Me.btnFanta = New System.Windows.Forms.Button()
        Me.panCans = New System.Windows.Forms.Panel()
        Me.panBottle = New System.Windows.Forms.Panel()
        Me.btnBtlPepsi = New System.Windows.Forms.Button()
        Me.btnBtlCoke = New System.Windows.Forms.Button()
        Me.btnBtlFanta = New System.Windows.Forms.Button()
        Me.lstQuantity = New System.Windows.Forms.ListBox()
        Me.lstSize = New System.Windows.Forms.ListBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lstItemName = New System.Windows.Forms.ListBox()
        Me.lstTotalPrice = New System.Windows.Forms.ListBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTP = New System.Windows.Forms.Label()
        Me.lblST = New System.Windows.Forms.Label()
        Me.lblVAT = New System.Windows.Forms.Label()
        Me.lblGT = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LandscapeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PortraitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColourToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HowToToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CallAssistanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VersionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.panQuantity = New System.Windows.Forms.Panel()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.btnDone = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.panPizza.SuspendLayout()
        Me.panStarters.SuspendLayout()
        Me.panDesserts.SuspendLayout()
        Me.panDrinks.SuspendLayout()
        Me.panBurgerSalad.SuspendLayout()
        Me.panSize.SuspendLayout()
        Me.panCans.SuspendLayout()
        Me.panBottle.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.panQuantity.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnPizza
        '
        Me.btnPizza.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnPizza.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPizza.Location = New System.Drawing.Point(26, 157)
        Me.btnPizza.Name = "btnPizza"
        Me.btnPizza.Size = New System.Drawing.Size(109, 40)
        Me.btnPizza.TabIndex = 0
        Me.btnPizza.Text = "Pizza"
        Me.btnPizza.UseVisualStyleBackColor = False
        '
        'btnStarters
        '
        Me.btnStarters.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnStarters.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStarters.Location = New System.Drawing.Point(141, 157)
        Me.btnStarters.Name = "btnStarters"
        Me.btnStarters.Size = New System.Drawing.Size(109, 40)
        Me.btnStarters.TabIndex = 1
        Me.btnStarters.Text = "Starters"
        Me.btnStarters.UseVisualStyleBackColor = False
        '
        'panPizza
        '
        Me.panPizza.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.panPizza.BackColor = System.Drawing.Color.Transparent
        Me.panPizza.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panPizza.Controls.Add(Me.btnSeafood)
        Me.panPizza.Controls.Add(Me.btnTandooriexpress)
        Me.panPizza.Controls.Add(Me.btnVegetarianhot)
        Me.panPizza.Controls.Add(Me.btnBeefeater)
        Me.panPizza.Controls.Add(Me.btnAmericanhot)
        Me.panPizza.Controls.Add(Me.btnMeatfeast)
        Me.panPizza.Controls.Add(Me.btnMediterraneanspecial)
        Me.panPizza.Controls.Add(Me.btnHampineapple)
        Me.panPizza.Controls.Add(Me.btnCheesetomato)
        Me.panPizza.Controls.Add(Me.btnMargherita)
        Me.panPizza.Location = New System.Drawing.Point(26, 203)
        Me.panPizza.Name = "panPizza"
        Me.panPizza.Size = New System.Drawing.Size(267, 270)
        Me.panPizza.TabIndex = 2
        Me.panPizza.Visible = False
        '
        'btnSeafood
        '
        Me.btnSeafood.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnSeafood.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSeafood.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnSeafood.Location = New System.Drawing.Point(133, 212)
        Me.btnSeafood.Name = "btnSeafood"
        Me.btnSeafood.Size = New System.Drawing.Size(109, 44)
        Me.btnSeafood.TabIndex = 8
        Me.btnSeafood.Text = "Seafood"
        Me.btnSeafood.UseVisualStyleBackColor = False
        '
        'btnTandooriexpress
        '
        Me.btnTandooriexpress.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTandooriexpress.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTandooriexpress.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnTandooriexpress.Location = New System.Drawing.Point(133, 162)
        Me.btnTandooriexpress.Name = "btnTandooriexpress"
        Me.btnTandooriexpress.Size = New System.Drawing.Size(109, 44)
        Me.btnTandooriexpress.TabIndex = 8
        Me.btnTandooriexpress.Text = "Tandoori express"
        Me.btnTandooriexpress.UseVisualStyleBackColor = False
        '
        'btnVegetarianhot
        '
        Me.btnVegetarianhot.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnVegetarianhot.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVegetarianhot.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnVegetarianhot.Location = New System.Drawing.Point(133, 112)
        Me.btnVegetarianhot.Name = "btnVegetarianhot"
        Me.btnVegetarianhot.Size = New System.Drawing.Size(109, 44)
        Me.btnVegetarianhot.TabIndex = 7
        Me.btnVegetarianhot.Text = "Vegetarian hot"
        Me.btnVegetarianhot.UseVisualStyleBackColor = False
        '
        'btnBeefeater
        '
        Me.btnBeefeater.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnBeefeater.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBeefeater.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBeefeater.Location = New System.Drawing.Point(133, 62)
        Me.btnBeefeater.Name = "btnBeefeater"
        Me.btnBeefeater.Size = New System.Drawing.Size(109, 44)
        Me.btnBeefeater.TabIndex = 6
        Me.btnBeefeater.Text = "Beefeater"
        Me.btnBeefeater.UseVisualStyleBackColor = False
        '
        'btnAmericanhot
        '
        Me.btnAmericanhot.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnAmericanhot.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAmericanhot.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnAmericanhot.Location = New System.Drawing.Point(133, 13)
        Me.btnAmericanhot.Name = "btnAmericanhot"
        Me.btnAmericanhot.Size = New System.Drawing.Size(109, 43)
        Me.btnAmericanhot.TabIndex = 5
        Me.btnAmericanhot.Text = "American hot"
        Me.btnAmericanhot.UseVisualStyleBackColor = False
        '
        'btnMeatfeast
        '
        Me.btnMeatfeast.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnMeatfeast.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMeatfeast.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnMeatfeast.Location = New System.Drawing.Point(21, 212)
        Me.btnMeatfeast.Name = "btnMeatfeast"
        Me.btnMeatfeast.Size = New System.Drawing.Size(106, 44)
        Me.btnMeatfeast.TabIndex = 4
        Me.btnMeatfeast.Text = "Meat feast"
        Me.btnMeatfeast.UseVisualStyleBackColor = False
        '
        'btnMediterraneanspecial
        '
        Me.btnMediterraneanspecial.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMediterraneanspecial.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMediterraneanspecial.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMediterraneanspecial.Location = New System.Drawing.Point(21, 162)
        Me.btnMediterraneanspecial.Name = "btnMediterraneanspecial"
        Me.btnMediterraneanspecial.Size = New System.Drawing.Size(106, 44)
        Me.btnMediterraneanspecial.TabIndex = 3
        Me.btnMediterraneanspecial.Text = "Mediterranean special"
        Me.btnMediterraneanspecial.UseVisualStyleBackColor = False
        '
        'btnHampineapple
        '
        Me.btnHampineapple.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnHampineapple.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnHampineapple.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnHampineapple.Location = New System.Drawing.Point(21, 112)
        Me.btnHampineapple.Name = "btnHampineapple"
        Me.btnHampineapple.Size = New System.Drawing.Size(106, 44)
        Me.btnHampineapple.TabIndex = 2
        Me.btnHampineapple.Text = "Ham and pineapple"
        Me.btnHampineapple.UseVisualStyleBackColor = False
        '
        'btnCheesetomato
        '
        Me.btnCheesetomato.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnCheesetomato.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCheesetomato.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnCheesetomato.Location = New System.Drawing.Point(21, 62)
        Me.btnCheesetomato.Name = "btnCheesetomato"
        Me.btnCheesetomato.Size = New System.Drawing.Size(106, 44)
        Me.btnCheesetomato.TabIndex = 1
        Me.btnCheesetomato.Text = "Cheese and tomato"
        Me.btnCheesetomato.UseVisualStyleBackColor = False
        '
        'btnMargherita
        '
        Me.btnMargherita.BackColor = System.Drawing.Color.White
        Me.btnMargherita.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMargherita.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMargherita.Location = New System.Drawing.Point(21, 12)
        Me.btnMargherita.Name = "btnMargherita"
        Me.btnMargherita.Size = New System.Drawing.Size(106, 44)
        Me.btnMargherita.TabIndex = 0
        Me.btnMargherita.Text = "Margherita"
        Me.btnMargherita.UseVisualStyleBackColor = False
        '
        'btnDesserts
        '
        Me.btnDesserts.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnDesserts.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDesserts.Location = New System.Drawing.Point(256, 157)
        Me.btnDesserts.Name = "btnDesserts"
        Me.btnDesserts.Size = New System.Drawing.Size(109, 40)
        Me.btnDesserts.TabIndex = 3
        Me.btnDesserts.Text = "Desserts"
        Me.btnDesserts.UseVisualStyleBackColor = False
        '
        'btnDrinks
        '
        Me.btnDrinks.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnDrinks.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDrinks.Location = New System.Drawing.Point(371, 157)
        Me.btnDrinks.Name = "btnDrinks"
        Me.btnDrinks.Size = New System.Drawing.Size(109, 40)
        Me.btnDrinks.TabIndex = 4
        Me.btnDrinks.Text = "Drinks"
        Me.btnDrinks.UseVisualStyleBackColor = False
        '
        'btnBurgerSalads
        '
        Me.btnBurgerSalads.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnBurgerSalads.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBurgerSalads.Location = New System.Drawing.Point(486, 157)
        Me.btnBurgerSalads.Name = "btnBurgerSalads"
        Me.btnBurgerSalads.Size = New System.Drawing.Size(109, 40)
        Me.btnBurgerSalads.TabIndex = 5
        Me.btnBurgerSalads.Text = "Burger / Salads"
        Me.btnBurgerSalads.UseVisualStyleBackColor = False
        '
        'panStarters
        '
        Me.panStarters.BackColor = System.Drawing.Color.Transparent
        Me.panStarters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panStarters.Controls.Add(Me.btnGarlicmushroombread)
        Me.panStarters.Controls.Add(Me.btnChickenspringroll)
        Me.panStarters.Controls.Add(Me.btnBBQchickenwings)
        Me.panStarters.Controls.Add(Me.btnVegetarianspringrolls)
        Me.panStarters.Controls.Add(Me.btnSpicychickenwings)
        Me.panStarters.Controls.Add(Me.btnChickennuggets)
        Me.panStarters.Controls.Add(Me.btnChips)
        Me.panStarters.Controls.Add(Me.btnPotatowedges)
        Me.panStarters.Controls.Add(Me.btnOnionrings)
        Me.panStarters.Controls.Add(Me.btnGarlicbread)
        Me.panStarters.Location = New System.Drawing.Point(26, 203)
        Me.panStarters.Name = "panStarters"
        Me.panStarters.Size = New System.Drawing.Size(267, 270)
        Me.panStarters.TabIndex = 6
        Me.panStarters.Visible = False
        '
        'btnGarlicmushroombread
        '
        Me.btnGarlicmushroombread.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnGarlicmushroombread.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGarlicmushroombread.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnGarlicmushroombread.Location = New System.Drawing.Point(133, 213)
        Me.btnGarlicmushroombread.Name = "btnGarlicmushroombread"
        Me.btnGarlicmushroombread.Size = New System.Drawing.Size(109, 44)
        Me.btnGarlicmushroombread.TabIndex = 0
        Me.btnGarlicmushroombread.Text = "Garlic mushroom bread"
        Me.btnGarlicmushroombread.UseVisualStyleBackColor = False
        '
        'btnChickenspringroll
        '
        Me.btnChickenspringroll.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnChickenspringroll.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnChickenspringroll.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnChickenspringroll.Location = New System.Drawing.Point(133, 163)
        Me.btnChickenspringroll.Name = "btnChickenspringroll"
        Me.btnChickenspringroll.Size = New System.Drawing.Size(109, 44)
        Me.btnChickenspringroll.TabIndex = 0
        Me.btnChickenspringroll.Text = "Chicken spring roll"
        Me.btnChickenspringroll.UseVisualStyleBackColor = False
        '
        'btnBBQchickenwings
        '
        Me.btnBBQchickenwings.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBBQchickenwings.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBBQchickenwings.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBBQchickenwings.Location = New System.Drawing.Point(133, 113)
        Me.btnBBQchickenwings.Name = "btnBBQchickenwings"
        Me.btnBBQchickenwings.Size = New System.Drawing.Size(109, 44)
        Me.btnBBQchickenwings.TabIndex = 0
        Me.btnBBQchickenwings.Text = "BBQ chicken wings"
        Me.btnBBQchickenwings.UseVisualStyleBackColor = False
        '
        'btnVegetarianspringrolls
        '
        Me.btnVegetarianspringrolls.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnVegetarianspringrolls.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVegetarianspringrolls.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVegetarianspringrolls.Location = New System.Drawing.Point(21, 213)
        Me.btnVegetarianspringrolls.Name = "btnVegetarianspringrolls"
        Me.btnVegetarianspringrolls.Size = New System.Drawing.Size(106, 44)
        Me.btnVegetarianspringrolls.TabIndex = 0
        Me.btnVegetarianspringrolls.Text = "Vegetarian spring rolls"
        Me.btnVegetarianspringrolls.UseVisualStyleBackColor = False
        '
        'btnSpicychickenwings
        '
        Me.btnSpicychickenwings.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnSpicychickenwings.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSpicychickenwings.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnSpicychickenwings.Location = New System.Drawing.Point(133, 63)
        Me.btnSpicychickenwings.Name = "btnSpicychickenwings"
        Me.btnSpicychickenwings.Size = New System.Drawing.Size(109, 44)
        Me.btnSpicychickenwings.TabIndex = 0
        Me.btnSpicychickenwings.Text = "Spicy chicken wings"
        Me.btnSpicychickenwings.UseVisualStyleBackColor = False
        '
        'btnChickennuggets
        '
        Me.btnChickennuggets.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnChickennuggets.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnChickennuggets.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnChickennuggets.Location = New System.Drawing.Point(21, 163)
        Me.btnChickennuggets.Name = "btnChickennuggets"
        Me.btnChickennuggets.Size = New System.Drawing.Size(106, 44)
        Me.btnChickennuggets.TabIndex = 0
        Me.btnChickennuggets.Text = "Chicken nuggets"
        Me.btnChickennuggets.UseVisualStyleBackColor = False
        '
        'btnChips
        '
        Me.btnChips.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnChips.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnChips.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnChips.Location = New System.Drawing.Point(133, 13)
        Me.btnChips.Name = "btnChips"
        Me.btnChips.Size = New System.Drawing.Size(109, 44)
        Me.btnChips.TabIndex = 0
        Me.btnChips.Text = "Chips"
        Me.btnChips.UseVisualStyleBackColor = False
        '
        'btnPotatowedges
        '
        Me.btnPotatowedges.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnPotatowedges.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPotatowedges.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnPotatowedges.Location = New System.Drawing.Point(21, 113)
        Me.btnPotatowedges.Name = "btnPotatowedges"
        Me.btnPotatowedges.Size = New System.Drawing.Size(106, 44)
        Me.btnPotatowedges.TabIndex = 0
        Me.btnPotatowedges.Text = "Potato wedges"
        Me.btnPotatowedges.UseVisualStyleBackColor = False
        '
        'btnOnionrings
        '
        Me.btnOnionrings.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnOnionrings.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnOnionrings.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnOnionrings.Location = New System.Drawing.Point(21, 63)
        Me.btnOnionrings.Name = "btnOnionrings"
        Me.btnOnionrings.Size = New System.Drawing.Size(106, 44)
        Me.btnOnionrings.TabIndex = 0
        Me.btnOnionrings.Text = "Onion rings"
        Me.btnOnionrings.UseVisualStyleBackColor = False
        '
        'btnGarlicbread
        '
        Me.btnGarlicbread.BackColor = System.Drawing.Color.White
        Me.btnGarlicbread.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGarlicbread.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnGarlicbread.Location = New System.Drawing.Point(21, 13)
        Me.btnGarlicbread.Name = "btnGarlicbread"
        Me.btnGarlicbread.Size = New System.Drawing.Size(106, 44)
        Me.btnGarlicbread.TabIndex = 0
        Me.btnGarlicbread.Text = "Garlic bread"
        Me.btnGarlicbread.UseVisualStyleBackColor = False
        '
        'panDesserts
        '
        Me.panDesserts.BackColor = System.Drawing.Color.Transparent
        Me.panDesserts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panDesserts.Controls.Add(Me.bntChokiesCream)
        Me.panDesserts.Controls.Add(Me.btnPineapplefritter)
        Me.panDesserts.Controls.Add(Me.btnBelgianchocolate)
        Me.panDesserts.Controls.Add(Me.btnBananafritter)
        Me.panDesserts.Controls.Add(Me.btnStrawberry)
        Me.panDesserts.Controls.Add(Me.btnStrawberrycake)
        Me.panDesserts.Controls.Add(Me.btnHaaganDazs)
        Me.panDesserts.Controls.Add(Me.btnVanilla)
        Me.panDesserts.Controls.Add(Me.btnTennesseecake)
        Me.panDesserts.Controls.Add(Me.btnChocolateCake)
        Me.panDesserts.Location = New System.Drawing.Point(26, 203)
        Me.panDesserts.Name = "panDesserts"
        Me.panDesserts.Size = New System.Drawing.Size(267, 270)
        Me.panDesserts.TabIndex = 7
        Me.panDesserts.Visible = False
        '
        'bntChokiesCream
        '
        Me.bntChokiesCream.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.bntChokiesCream.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.bntChokiesCream.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.bntChokiesCream.Location = New System.Drawing.Point(133, 213)
        Me.bntChokiesCream.Name = "bntChokiesCream"
        Me.bntChokiesCream.Size = New System.Drawing.Size(106, 44)
        Me.bntChokiesCream.TabIndex = 0
        Me.bntChokiesCream.Text = "Chokies Cream"
        Me.bntChokiesCream.UseVisualStyleBackColor = False
        '
        'btnPineapplefritter
        '
        Me.btnPineapplefritter.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnPineapplefritter.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPineapplefritter.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnPineapplefritter.Location = New System.Drawing.Point(21, 213)
        Me.btnPineapplefritter.Name = "btnPineapplefritter"
        Me.btnPineapplefritter.Size = New System.Drawing.Size(106, 44)
        Me.btnPineapplefritter.TabIndex = 0
        Me.btnPineapplefritter.Text = "Pineapple fritter"
        Me.btnPineapplefritter.UseVisualStyleBackColor = False
        '
        'btnBelgianchocolate
        '
        Me.btnBelgianchocolate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBelgianchocolate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBelgianchocolate.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBelgianchocolate.Location = New System.Drawing.Point(133, 163)
        Me.btnBelgianchocolate.Name = "btnBelgianchocolate"
        Me.btnBelgianchocolate.Size = New System.Drawing.Size(106, 44)
        Me.btnBelgianchocolate.TabIndex = 0
        Me.btnBelgianchocolate.Text = "Belgian chocolate"
        Me.btnBelgianchocolate.UseVisualStyleBackColor = False
        '
        'btnBananafritter
        '
        Me.btnBananafritter.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBananafritter.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBananafritter.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBananafritter.Location = New System.Drawing.Point(21, 163)
        Me.btnBananafritter.Name = "btnBananafritter"
        Me.btnBananafritter.Size = New System.Drawing.Size(106, 44)
        Me.btnBananafritter.TabIndex = 0
        Me.btnBananafritter.Text = "Banana fritter"
        Me.btnBananafritter.UseVisualStyleBackColor = False
        '
        'btnStrawberry
        '
        Me.btnStrawberry.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnStrawberry.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnStrawberry.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnStrawberry.Location = New System.Drawing.Point(133, 113)
        Me.btnStrawberry.Name = "btnStrawberry"
        Me.btnStrawberry.Size = New System.Drawing.Size(106, 44)
        Me.btnStrawberry.TabIndex = 0
        Me.btnStrawberry.Text = "Strawberry"
        Me.btnStrawberry.UseVisualStyleBackColor = False
        '
        'btnStrawberrycake
        '
        Me.btnStrawberrycake.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnStrawberrycake.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnStrawberrycake.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnStrawberrycake.Location = New System.Drawing.Point(21, 113)
        Me.btnStrawberrycake.Name = "btnStrawberrycake"
        Me.btnStrawberrycake.Size = New System.Drawing.Size(106, 44)
        Me.btnStrawberrycake.TabIndex = 0
        Me.btnStrawberrycake.Text = "Strawberry cake"
        Me.btnStrawberrycake.UseVisualStyleBackColor = False
        '
        'btnHaaganDazs
        '
        Me.btnHaaganDazs.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnHaaganDazs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnHaaganDazs.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnHaaganDazs.Location = New System.Drawing.Point(133, 13)
        Me.btnHaaganDazs.Name = "btnHaaganDazs"
        Me.btnHaaganDazs.Size = New System.Drawing.Size(106, 44)
        Me.btnHaaganDazs.TabIndex = 0
        Me.btnHaaganDazs.Text = "Haagan Dazs"
        Me.btnHaaganDazs.UseVisualStyleBackColor = False
        '
        'btnVanilla
        '
        Me.btnVanilla.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnVanilla.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVanilla.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnVanilla.Location = New System.Drawing.Point(133, 63)
        Me.btnVanilla.Name = "btnVanilla"
        Me.btnVanilla.Size = New System.Drawing.Size(106, 44)
        Me.btnVanilla.TabIndex = 0
        Me.btnVanilla.Text = "Vanilla"
        Me.btnVanilla.UseVisualStyleBackColor = False
        '
        'btnTennesseecake
        '
        Me.btnTennesseecake.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnTennesseecake.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTennesseecake.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnTennesseecake.Location = New System.Drawing.Point(21, 63)
        Me.btnTennesseecake.Name = "btnTennesseecake"
        Me.btnTennesseecake.Size = New System.Drawing.Size(106, 44)
        Me.btnTennesseecake.TabIndex = 0
        Me.btnTennesseecake.Text = "Tennessee cake"
        Me.btnTennesseecake.UseVisualStyleBackColor = False
        '
        'btnChocolateCake
        '
        Me.btnChocolateCake.BackColor = System.Drawing.Color.White
        Me.btnChocolateCake.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnChocolateCake.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnChocolateCake.Location = New System.Drawing.Point(21, 13)
        Me.btnChocolateCake.Name = "btnChocolateCake"
        Me.btnChocolateCake.Size = New System.Drawing.Size(106, 44)
        Me.btnChocolateCake.TabIndex = 0
        Me.btnChocolateCake.Text = "Chocolate cake"
        Me.btnChocolateCake.UseVisualStyleBackColor = False
        '
        'panDrinks
        '
        Me.panDrinks.BackColor = System.Drawing.Color.Transparent
        Me.panDrinks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panDrinks.Controls.Add(Me.btnCans)
        Me.panDrinks.Controls.Add(Me.btnPureapplejuice)
        Me.panDrinks.Controls.Add(Me.btnPureorangejuice)
        Me.panDrinks.Controls.Add(Me.btnChocolate)
        Me.panDrinks.Controls.Add(Me.btnCappuccino)
        Me.panDrinks.Controls.Add(Me.btnRegulartea)
        Me.panDrinks.Controls.Add(Me.btnBottle)
        Me.panDrinks.Controls.Add(Me.btnRegularcoffe)
        Me.panDrinks.Location = New System.Drawing.Point(26, 203)
        Me.panDrinks.Name = "panDrinks"
        Me.panDrinks.Size = New System.Drawing.Size(267, 270)
        Me.panDrinks.TabIndex = 7
        Me.panDrinks.Visible = False
        '
        'btnCans
        '
        Me.btnCans.BackColor = System.Drawing.Color.White
        Me.btnCans.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCans.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnCans.Location = New System.Drawing.Point(21, 13)
        Me.btnCans.Name = "btnCans"
        Me.btnCans.Size = New System.Drawing.Size(106, 44)
        Me.btnCans.TabIndex = 0
        Me.btnCans.Text = "Cans"
        Me.btnCans.UseVisualStyleBackColor = False
        '
        'btnPureapplejuice
        '
        Me.btnPureapplejuice.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPureapplejuice.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPureapplejuice.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnPureapplejuice.Location = New System.Drawing.Point(21, 163)
        Me.btnPureapplejuice.Name = "btnPureapplejuice"
        Me.btnPureapplejuice.Size = New System.Drawing.Size(106, 44)
        Me.btnPureapplejuice.TabIndex = 0
        Me.btnPureapplejuice.Text = "Pure apple juice"
        Me.btnPureapplejuice.UseVisualStyleBackColor = False
        '
        'btnPureorangejuice
        '
        Me.btnPureorangejuice.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnPureorangejuice.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPureorangejuice.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnPureorangejuice.Location = New System.Drawing.Point(21, 113)
        Me.btnPureorangejuice.Name = "btnPureorangejuice"
        Me.btnPureorangejuice.Size = New System.Drawing.Size(106, 44)
        Me.btnPureorangejuice.TabIndex = 0
        Me.btnPureorangejuice.Text = "Pure orange juice"
        Me.btnPureorangejuice.UseVisualStyleBackColor = False
        '
        'btnChocolate
        '
        Me.btnChocolate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnChocolate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnChocolate.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnChocolate.Location = New System.Drawing.Point(133, 163)
        Me.btnChocolate.Name = "btnChocolate"
        Me.btnChocolate.Size = New System.Drawing.Size(106, 44)
        Me.btnChocolate.TabIndex = 0
        Me.btnChocolate.Text = "Chocolate"
        Me.btnChocolate.UseVisualStyleBackColor = False
        '
        'btnCappuccino
        '
        Me.btnCappuccino.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCappuccino.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCappuccino.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnCappuccino.Location = New System.Drawing.Point(133, 113)
        Me.btnCappuccino.Name = "btnCappuccino"
        Me.btnCappuccino.Size = New System.Drawing.Size(106, 44)
        Me.btnCappuccino.TabIndex = 0
        Me.btnCappuccino.Text = "Cappuccino"
        Me.btnCappuccino.UseVisualStyleBackColor = False
        '
        'btnRegulartea
        '
        Me.btnRegulartea.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnRegulartea.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRegulartea.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnRegulartea.Location = New System.Drawing.Point(133, 63)
        Me.btnRegulartea.Name = "btnRegulartea"
        Me.btnRegulartea.Size = New System.Drawing.Size(106, 44)
        Me.btnRegulartea.TabIndex = 0
        Me.btnRegulartea.Text = "Regular tea"
        Me.btnRegulartea.UseVisualStyleBackColor = False
        '
        'btnBottle
        '
        Me.btnBottle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnBottle.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBottle.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBottle.Location = New System.Drawing.Point(21, 63)
        Me.btnBottle.Name = "btnBottle"
        Me.btnBottle.Size = New System.Drawing.Size(106, 44)
        Me.btnBottle.TabIndex = 0
        Me.btnBottle.Text = "Bottle"
        Me.btnBottle.UseVisualStyleBackColor = False
        '
        'btnRegularcoffe
        '
        Me.btnRegularcoffe.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnRegularcoffe.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRegularcoffe.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnRegularcoffe.Location = New System.Drawing.Point(133, 13)
        Me.btnRegularcoffe.Name = "btnRegularcoffe"
        Me.btnRegularcoffe.Size = New System.Drawing.Size(106, 44)
        Me.btnRegularcoffe.TabIndex = 0
        Me.btnRegularcoffe.Text = "Regular coffee"
        Me.btnRegularcoffe.UseVisualStyleBackColor = False
        '
        'panBurgerSalad
        '
        Me.panBurgerSalad.BackColor = System.Drawing.Color.Transparent
        Me.panBurgerSalad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panBurgerSalad.Controls.Add(Me.btnMixedgreen)
        Me.panBurgerSalad.Controls.Add(Me.btnChickenburger)
        Me.panBurgerSalad.Controls.Add(Me.btnFishburger)
        Me.panBurgerSalad.Controls.Add(Me.btnVegetableburger)
        Me.panBurgerSalad.Controls.Add(Me.btnQuarterpounder)
        Me.panBurgerSalad.Controls.Add(Me.btnHumus)
        Me.panBurgerSalad.Controls.Add(Me.btnFreshsalad)
        Me.panBurgerSalad.Controls.Add(Me.btnColeslaw)
        Me.panBurgerSalad.Location = New System.Drawing.Point(26, 203)
        Me.panBurgerSalad.Name = "panBurgerSalad"
        Me.panBurgerSalad.Size = New System.Drawing.Size(267, 270)
        Me.panBurgerSalad.TabIndex = 8
        Me.panBurgerSalad.Visible = False
        '
        'btnMixedgreen
        '
        Me.btnMixedgreen.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMixedgreen.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMixedgreen.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnMixedgreen.Location = New System.Drawing.Point(133, 163)
        Me.btnMixedgreen.Name = "btnMixedgreen"
        Me.btnMixedgreen.Size = New System.Drawing.Size(106, 44)
        Me.btnMixedgreen.TabIndex = 0
        Me.btnMixedgreen.Text = "Mixed green"
        Me.btnMixedgreen.UseVisualStyleBackColor = False
        '
        'btnChickenburger
        '
        Me.btnChickenburger.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnChickenburger.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnChickenburger.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnChickenburger.Location = New System.Drawing.Point(21, 163)
        Me.btnChickenburger.Name = "btnChickenburger"
        Me.btnChickenburger.Size = New System.Drawing.Size(106, 44)
        Me.btnChickenburger.TabIndex = 0
        Me.btnChickenburger.Text = "Chicken burger"
        Me.btnChickenburger.UseVisualStyleBackColor = False
        '
        'btnFishburger
        '
        Me.btnFishburger.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnFishburger.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFishburger.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnFishburger.Location = New System.Drawing.Point(21, 113)
        Me.btnFishburger.Name = "btnFishburger"
        Me.btnFishburger.Size = New System.Drawing.Size(106, 44)
        Me.btnFishburger.TabIndex = 0
        Me.btnFishburger.Text = "Fish burger"
        Me.btnFishburger.UseVisualStyleBackColor = False
        '
        'btnVegetableburger
        '
        Me.btnVegetableburger.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnVegetableburger.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVegetableburger.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnVegetableburger.Location = New System.Drawing.Point(21, 63)
        Me.btnVegetableburger.Name = "btnVegetableburger"
        Me.btnVegetableburger.Size = New System.Drawing.Size(106, 44)
        Me.btnVegetableburger.TabIndex = 0
        Me.btnVegetableburger.Text = "Vegetable burger"
        Me.btnVegetableburger.UseVisualStyleBackColor = False
        '
        'btnQuarterpounder
        '
        Me.btnQuarterpounder.BackColor = System.Drawing.Color.White
        Me.btnQuarterpounder.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuarterpounder.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnQuarterpounder.Location = New System.Drawing.Point(21, 13)
        Me.btnQuarterpounder.Name = "btnQuarterpounder"
        Me.btnQuarterpounder.Size = New System.Drawing.Size(106, 44)
        Me.btnQuarterpounder.TabIndex = 0
        Me.btnQuarterpounder.Text = "Quarter pounder"
        Me.btnQuarterpounder.UseVisualStyleBackColor = False
        '
        'btnHumus
        '
        Me.btnHumus.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnHumus.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnHumus.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnHumus.Location = New System.Drawing.Point(133, 113)
        Me.btnHumus.Name = "btnHumus"
        Me.btnHumus.Size = New System.Drawing.Size(106, 44)
        Me.btnHumus.TabIndex = 0
        Me.btnHumus.Text = "Humus"
        Me.btnHumus.UseVisualStyleBackColor = False
        '
        'btnFreshsalad
        '
        Me.btnFreshsalad.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnFreshsalad.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFreshsalad.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnFreshsalad.Location = New System.Drawing.Point(133, 13)
        Me.btnFreshsalad.Name = "btnFreshsalad"
        Me.btnFreshsalad.Size = New System.Drawing.Size(106, 44)
        Me.btnFreshsalad.TabIndex = 0
        Me.btnFreshsalad.Text = "Fresh salad"
        Me.btnFreshsalad.UseVisualStyleBackColor = False
        '
        'btnColeslaw
        '
        Me.btnColeslaw.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnColeslaw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnColeslaw.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnColeslaw.Location = New System.Drawing.Point(133, 63)
        Me.btnColeslaw.Name = "btnColeslaw"
        Me.btnColeslaw.Size = New System.Drawing.Size(106, 44)
        Me.btnColeslaw.TabIndex = 0
        Me.btnColeslaw.Text = "Coleslaw"
        Me.btnColeslaw.UseVisualStyleBackColor = False
        '
        'panSize
        '
        Me.panSize.BackColor = System.Drawing.Color.Transparent
        Me.panSize.Controls.Add(Me.btn15XL)
        Me.panSize.Controls.Add(Me.btn9M)
        Me.panSize.Controls.Add(Me.btn12L)
        Me.panSize.Controls.Add(Me.btn18XXL)
        Me.panSize.Location = New System.Drawing.Point(26, 203)
        Me.panSize.Name = "panSize"
        Me.panSize.Size = New System.Drawing.Size(267, 121)
        Me.panSize.TabIndex = 9
        Me.panSize.Visible = False
        '
        'btn15XL
        '
        Me.btn15XL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn15XL.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn15XL.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btn15XL.Location = New System.Drawing.Point(21, 63)
        Me.btn15XL.Name = "btn15XL"
        Me.btn15XL.Size = New System.Drawing.Size(106, 44)
        Me.btn15XL.TabIndex = 0
        Me.btn15XL.Text = "15 (XL)"
        Me.btn15XL.UseVisualStyleBackColor = False
        '
        'btn9M
        '
        Me.btn9M.BackColor = System.Drawing.Color.White
        Me.btn9M.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn9M.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btn9M.Location = New System.Drawing.Point(21, 13)
        Me.btn9M.Name = "btn9M"
        Me.btn9M.Size = New System.Drawing.Size(106, 44)
        Me.btn9M.TabIndex = 0
        Me.btn9M.Text = "9 (M)"
        Me.btn9M.UseVisualStyleBackColor = False
        '
        'btn12L
        '
        Me.btn12L.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn12L.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn12L.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btn12L.Location = New System.Drawing.Point(133, 13)
        Me.btn12L.Name = "btn12L"
        Me.btn12L.Size = New System.Drawing.Size(106, 44)
        Me.btn12L.TabIndex = 0
        Me.btn12L.Text = "12 (L)"
        Me.btn12L.UseVisualStyleBackColor = False
        '
        'btn18XXL
        '
        Me.btn18XXL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn18XXL.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn18XXL.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btn18XXL.Location = New System.Drawing.Point(133, 63)
        Me.btn18XXL.Name = "btn18XXL"
        Me.btn18XXL.Size = New System.Drawing.Size(106, 44)
        Me.btn18XXL.TabIndex = 0
        Me.btn18XXL.Text = "18 (XXL)"
        Me.btn18XXL.UseVisualStyleBackColor = False
        '
        'btnCoke
        '
        Me.btnCoke.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnCoke.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCoke.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnCoke.Location = New System.Drawing.Point(133, 13)
        Me.btnCoke.Name = "btnCoke"
        Me.btnCoke.Size = New System.Drawing.Size(106, 44)
        Me.btnCoke.TabIndex = 0
        Me.btnCoke.Text = "Coke"
        Me.btnCoke.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button48.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button48.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Button48.Location = New System.Drawing.Point(26, 479)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(269, 40)
        Me.Button48.TabIndex = 0
        Me.Button48.Text = "Remove Item"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'btnPepsi
        '
        Me.btnPepsi.BackColor = System.Drawing.Color.White
        Me.btnPepsi.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPepsi.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnPepsi.Location = New System.Drawing.Point(21, 12)
        Me.btnPepsi.Name = "btnPepsi"
        Me.btnPepsi.Size = New System.Drawing.Size(106, 44)
        Me.btnPepsi.TabIndex = 0
        Me.btnPepsi.Text = "Pepsi"
        Me.btnPepsi.UseVisualStyleBackColor = False
        '
        'btnFanta
        '
        Me.btnFanta.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnFanta.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFanta.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnFanta.Location = New System.Drawing.Point(21, 63)
        Me.btnFanta.Name = "btnFanta"
        Me.btnFanta.Size = New System.Drawing.Size(106, 44)
        Me.btnFanta.TabIndex = 0
        Me.btnFanta.Text = "Fanta"
        Me.btnFanta.UseVisualStyleBackColor = False
        '
        'panCans
        '
        Me.panCans.BackColor = System.Drawing.Color.Transparent
        Me.panCans.Controls.Add(Me.btnPepsi)
        Me.panCans.Controls.Add(Me.btnCoke)
        Me.panCans.Controls.Add(Me.btnFanta)
        Me.panCans.Location = New System.Drawing.Point(26, 203)
        Me.panCans.Name = "panCans"
        Me.panCans.Size = New System.Drawing.Size(262, 93)
        Me.panCans.TabIndex = 10
        Me.panCans.Visible = False
        '
        'panBottle
        '
        Me.panBottle.BackColor = System.Drawing.Color.Transparent
        Me.panBottle.Controls.Add(Me.btnBtlPepsi)
        Me.panBottle.Controls.Add(Me.btnBtlCoke)
        Me.panBottle.Controls.Add(Me.btnBtlFanta)
        Me.panBottle.Location = New System.Drawing.Point(26, 203)
        Me.panBottle.Name = "panBottle"
        Me.panBottle.Size = New System.Drawing.Size(267, 121)
        Me.panBottle.TabIndex = 11
        Me.panBottle.Visible = False
        '
        'btnBtlPepsi
        '
        Me.btnBtlPepsi.BackColor = System.Drawing.Color.White
        Me.btnBtlPepsi.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBtlPepsi.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBtlPepsi.Location = New System.Drawing.Point(21, 12)
        Me.btnBtlPepsi.Name = "btnBtlPepsi"
        Me.btnBtlPepsi.Size = New System.Drawing.Size(106, 44)
        Me.btnBtlPepsi.TabIndex = 0
        Me.btnBtlPepsi.Text = "Pepsi"
        Me.btnBtlPepsi.UseVisualStyleBackColor = False
        '
        'btnBtlCoke
        '
        Me.btnBtlCoke.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnBtlCoke.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBtlCoke.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBtlCoke.Location = New System.Drawing.Point(133, 13)
        Me.btnBtlCoke.Name = "btnBtlCoke"
        Me.btnBtlCoke.Size = New System.Drawing.Size(106, 44)
        Me.btnBtlCoke.TabIndex = 0
        Me.btnBtlCoke.Text = "Coke"
        Me.btnBtlCoke.UseVisualStyleBackColor = False
        '
        'btnBtlFanta
        '
        Me.btnBtlFanta.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnBtlFanta.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBtlFanta.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnBtlFanta.Location = New System.Drawing.Point(21, 63)
        Me.btnBtlFanta.Name = "btnBtlFanta"
        Me.btnBtlFanta.Size = New System.Drawing.Size(106, 44)
        Me.btnBtlFanta.TabIndex = 0
        Me.btnBtlFanta.Text = "Fanta"
        Me.btnBtlFanta.UseVisualStyleBackColor = False
        '
        'lstQuantity
        '
        Me.lstQuantity.FormattingEnabled = True
        Me.lstQuantity.Location = New System.Drawing.Point(310, 230)
        Me.lstQuantity.Name = "lstQuantity"
        Me.lstQuantity.Size = New System.Drawing.Size(66, 290)
        Me.lstQuantity.TabIndex = 12
        '
        'lstSize
        '
        Me.lstSize.FormattingEnabled = True
        Me.lstSize.Location = New System.Drawing.Point(371, 230)
        Me.lstSize.Name = "lstSize"
        Me.lstSize.Size = New System.Drawing.Size(95, 290)
        Me.lstSize.TabIndex = 13
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Papyrus", 20.25!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.LawnGreen
        Me.lblTitle.Location = New System.Drawing.Point(270, 51)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(325, 42)
        Me.lblTitle.TabIndex = 14
        Me.lblTitle.Text = "Welcome to Pizza 4 You"
        '
        'lstItemName
        '
        Me.lstItemName.FormattingEnabled = True
        Me.lstItemName.Location = New System.Drawing.Point(456, 230)
        Me.lstItemName.Name = "lstItemName"
        Me.lstItemName.Size = New System.Drawing.Size(186, 290)
        Me.lstItemName.TabIndex = 15
        '
        'lstTotalPrice
        '
        Me.lstTotalPrice.FormattingEnabled = True
        Me.lstTotalPrice.Location = New System.Drawing.Point(634, 230)
        Me.lstTotalPrice.Name = "lstTotalPrice"
        Me.lstTotalPrice.Size = New System.Drawing.Size(94, 290)
        Me.lstTotalPrice.TabIndex = 16
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"})
        Me.ComboBox1.Location = New System.Drawing.Point(141, 113)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(107, 21)
        Me.ComboBox1.TabIndex = 17
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.SpringGreen
        Me.btnCalculate.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnCalculate.Location = New System.Drawing.Point(734, 230)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(150, 40)
        Me.btnCalculate.TabIndex = 18
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(734, 326)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 18)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Total Items"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(734, 353)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 18)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Sub-Total"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(734, 385)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 18)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "VAT"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(734, 414)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 18)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Grand-Total"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(25, 116)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 15)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Table"
        '
        'lblTP
        '
        Me.lblTP.AutoSize = True
        Me.lblTP.BackColor = System.Drawing.Color.Transparent
        Me.lblTP.ForeColor = System.Drawing.Color.White
        Me.lblTP.Location = New System.Drawing.Point(828, 331)
        Me.lblTP.Name = "lblTP"
        Me.lblTP.Size = New System.Drawing.Size(21, 13)
        Me.lblTP.TabIndex = 24
        Me.lblTP.Text = "TP"
        '
        'lblST
        '
        Me.lblST.AutoSize = True
        Me.lblST.BackColor = System.Drawing.Color.Transparent
        Me.lblST.ForeColor = System.Drawing.Color.White
        Me.lblST.Location = New System.Drawing.Point(828, 358)
        Me.lblST.Name = "lblST"
        Me.lblST.Size = New System.Drawing.Size(21, 13)
        Me.lblST.TabIndex = 25
        Me.lblST.Text = "ST"
        '
        'lblVAT
        '
        Me.lblVAT.AutoSize = True
        Me.lblVAT.BackColor = System.Drawing.Color.Transparent
        Me.lblVAT.ForeColor = System.Drawing.Color.White
        Me.lblVAT.Location = New System.Drawing.Point(828, 388)
        Me.lblVAT.Name = "lblVAT"
        Me.lblVAT.Size = New System.Drawing.Size(14, 13)
        Me.lblVAT.TabIndex = 26
        Me.lblVAT.Text = "V"
        '
        'lblGT
        '
        Me.lblGT.AutoSize = True
        Me.lblGT.BackColor = System.Drawing.Color.Transparent
        Me.lblGT.ForeColor = System.Drawing.Color.White
        Me.lblGT.Location = New System.Drawing.Point(828, 417)
        Me.lblGT.Name = "lblGT"
        Me.lblGT.Size = New System.Drawing.Size(22, 13)
        Me.lblGT.TabIndex = 27
        Me.lblGT.Text = "GT"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(307, 212)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 15)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "Quantity"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(368, 212)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 15)
        Me.Label11.TabIndex = 29
        Me.Label11.Text = "Size"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(453, 212)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 15)
        Me.Label12.TabIndex = 30
        Me.Label12.Text = "Item Name"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(631, 212)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 15)
        Me.Label13.TabIndex = 31
        Me.Label13.Text = "Total Price"
        '
        'btnOrder
        '
        Me.btnOrder.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btnOrder.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnOrder.Location = New System.Drawing.Point(734, 276)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(150, 40)
        Me.btnOrder.TabIndex = 32
        Me.btnOrder.Text = "Order"
        Me.btnOrder.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Button3.Location = New System.Drawing.Point(26, 525)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(269, 40)
        Me.Button3.TabIndex = 33
        Me.Button3.Text = "Clear"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Magenta
        Me.Button4.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Button4.Location = New System.Drawing.Point(733, 463)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(151, 40)
        Me.Button4.TabIndex = 34
        Me.Button4.Text = "Log Out"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(310, 545)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(418, 20)
        Me.TextBox1.TabIndex = 35
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(307, 527)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(168, 15)
        Me.Label14.TabIndex = 36
        Me.Label14.Text = "Additional Customer Request"
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(734, 545)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtPrice.TabIndex = 37
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(731, 527)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(34, 15)
        Me.Label15.TabIndex = 38
        Me.Label15.Text = "Price"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(25, 80)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(33, 15)
        Me.Label16.TabIndex = 39
        Me.Label16.Text = "Date"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Transparent
        Me.lblDate.ForeColor = System.Drawing.Color.White
        Me.lblDate.Location = New System.Drawing.Point(138, 80)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(65, 13)
        Me.lblDate.TabIndex = 40
        Me.lblDate.Text = "11/03/2014"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(25, 45)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(34, 15)
        Me.Label18.TabIndex = 41
        Me.Label18.Text = "Time"
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.ForeColor = System.Drawing.Color.White
        Me.lblTime.Location = New System.Drawing.Point(138, 45)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(34, 13)
        Me.lblTime.TabIndex = 42
        Me.lblTime.Text = "12:34"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(622, 45)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(262, 152)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 43
        Me.PictureBox1.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Crimson
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.EditToolStripMenuItem, Me.ColourToolStripMenuItem, Me.HelpToolStripMenuItem, Me.VersionToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(904, 28)
        Me.MenuStrip1.TabIndex = 44
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem, Me.PrintToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.ToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(44, 24)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(109, 24)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(109, 24)
        Me.PrintToolStripMenuItem.Text = "Print"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(109, 24)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ModeToolStripMenuItem})
        Me.EditToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(47, 24)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ModeToolStripMenuItem
        '
        Me.ModeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LandscapeToolStripMenuItem, Me.PortraitToolStripMenuItem})
        Me.ModeToolStripMenuItem.Name = "ModeToolStripMenuItem"
        Me.ModeToolStripMenuItem.Size = New System.Drawing.Size(117, 24)
        Me.ModeToolStripMenuItem.Text = "Mode"
        '
        'LandscapeToolStripMenuItem
        '
        Me.LandscapeToolStripMenuItem.Name = "LandscapeToolStripMenuItem"
        Me.LandscapeToolStripMenuItem.Size = New System.Drawing.Size(148, 24)
        Me.LandscapeToolStripMenuItem.Text = "Landscape"
        '
        'PortraitToolStripMenuItem
        '
        Me.PortraitToolStripMenuItem.Name = "PortraitToolStripMenuItem"
        Me.PortraitToolStripMenuItem.Size = New System.Drawing.Size(148, 24)
        Me.PortraitToolStripMenuItem.Text = "Portrait"
        '
        'ColourToolStripMenuItem
        '
        Me.ColourToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ColourToolStripMenuItem.Name = "ColourToolStripMenuItem"
        Me.ColourToolStripMenuItem.Size = New System.Drawing.Size(65, 24)
        Me.ColourToolStripMenuItem.Text = "Colour"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HowToToolStripMenuItem, Me.CallAssistanceToolStripMenuItem})
        Me.HelpToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(53, 24)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'HowToToolStripMenuItem
        '
        Me.HowToToolStripMenuItem.Name = "HowToToolStripMenuItem"
        Me.HowToToolStripMenuItem.Size = New System.Drawing.Size(173, 24)
        Me.HowToToolStripMenuItem.Text = "How to"
        '
        'CallAssistanceToolStripMenuItem
        '
        Me.CallAssistanceToolStripMenuItem.Name = "CallAssistanceToolStripMenuItem"
        Me.CallAssistanceToolStripMenuItem.Size = New System.Drawing.Size(173, 24)
        Me.CallAssistanceToolStripMenuItem.Text = "Call assistance"
        '
        'VersionToolStripMenuItem
        '
        Me.VersionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.VersionToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VersionToolStripMenuItem.Name = "VersionToolStripMenuItem"
        Me.VersionToolStripMenuItem.Size = New System.Drawing.Size(70, 24)
        Me.VersionToolStripMenuItem.Text = "Version"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(119, 24)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'panQuantity
        '
        Me.panQuantity.BackColor = System.Drawing.Color.Transparent
        Me.panQuantity.Controls.Add(Me.btn0)
        Me.panQuantity.Controls.Add(Me.txtQuantity)
        Me.panQuantity.Controls.Add(Me.btnDone)
        Me.panQuantity.Controls.Add(Me.btn9)
        Me.panQuantity.Controls.Add(Me.btn8)
        Me.panQuantity.Controls.Add(Me.btn7)
        Me.panQuantity.Controls.Add(Me.btn6)
        Me.panQuantity.Controls.Add(Me.btn3)
        Me.panQuantity.Controls.Add(Me.btn5)
        Me.panQuantity.Controls.Add(Me.btn2)
        Me.panQuantity.Controls.Add(Me.btn4)
        Me.panQuantity.Controls.Add(Me.btn1)
        Me.panQuantity.Location = New System.Drawing.Point(26, 203)
        Me.panQuantity.Name = "panQuantity"
        Me.panQuantity.Size = New System.Drawing.Size(267, 270)
        Me.panQuantity.TabIndex = 47
        Me.panQuantity.Visible = False
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn0.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn0.Location = New System.Drawing.Point(11, 209)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(80, 52)
        Me.btn0.TabIndex = 11
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'txtQuantity
        '
        Me.txtQuantity.Location = New System.Drawing.Point(11, 12)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(244, 20)
        Me.txtQuantity.TabIndex = 10
        '
        'btnDone
        '
        Me.btnDone.BackColor = System.Drawing.Color.Yellow
        Me.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDone.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnDone.Location = New System.Drawing.Point(93, 209)
        Me.btnDone.Name = "btnDone"
        Me.btnDone.Size = New System.Drawing.Size(162, 52)
        Me.btnDone.TabIndex = 9
        Me.btnDone.Text = "Done"
        Me.btnDone.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn9.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn9.Location = New System.Drawing.Point(175, 153)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(80, 50)
        Me.btn9.TabIndex = 8
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn8.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn8.Location = New System.Drawing.Point(93, 153)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(80, 50)
        Me.btn8.TabIndex = 7
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn7.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn7.Location = New System.Drawing.Point(11, 153)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(80, 50)
        Me.btn7.TabIndex = 6
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn6.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn6.Location = New System.Drawing.Point(175, 96)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(80, 52)
        Me.btn6.TabIndex = 5
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn3.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn3.Location = New System.Drawing.Point(175, 38)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(80, 52)
        Me.btn3.TabIndex = 4
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn5.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn5.Location = New System.Drawing.Point(93, 96)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(80, 52)
        Me.btn5.TabIndex = 3
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn2.Location = New System.Drawing.Point(93, 38)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(80, 52)
        Me.btn2.TabIndex = 2
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn4.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn4.Location = New System.Drawing.Point(11, 96)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(80, 52)
        Me.btn4.TabIndex = 1
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.White
        Me.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn1.Location = New System.Drawing.Point(11, 38)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(80, 52)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Location = New System.Drawing.Point(1143, 1067)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(10, 13)
        Me.Label17.TabIndex = 48
        Me.Label17.Text = "."
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(904, 583)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.panQuantity)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.panPizza)
        Me.Controls.Add(Me.panDesserts)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.panCans)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.panBurgerSalad)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.lblGT)
        Me.Controls.Add(Me.lblVAT)
        Me.Controls.Add(Me.lblST)
        Me.Controls.Add(Me.lblTP)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.lstTotalPrice)
        Me.Controls.Add(Me.lstItemName)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.lstSize)
        Me.Controls.Add(Me.lstQuantity)
        Me.Controls.Add(Me.panBottle)
        Me.Controls.Add(Me.panSize)
        Me.Controls.Add(Me.panStarters)
        Me.Controls.Add(Me.panDrinks)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.btnBurgerSalads)
        Me.Controls.Add(Me.btnDrinks)
        Me.Controls.Add(Me.btnDesserts)
        Me.Controls.Add(Me.btnStarters)
        Me.Controls.Add(Me.btnPizza)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pizza 4 You"
        Me.panPizza.ResumeLayout(False)
        Me.panStarters.ResumeLayout(False)
        Me.panDesserts.ResumeLayout(False)
        Me.panDrinks.ResumeLayout(False)
        Me.panBurgerSalad.ResumeLayout(False)
        Me.panSize.ResumeLayout(False)
        Me.panCans.ResumeLayout(False)
        Me.panBottle.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.panQuantity.ResumeLayout(False)
        Me.panQuantity.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPizza As System.Windows.Forms.Button
    Friend WithEvents btnStarters As System.Windows.Forms.Button
    Friend WithEvents panPizza As System.Windows.Forms.Panel
    Friend WithEvents btnHampineapple As System.Windows.Forms.Button
    Friend WithEvents btnCheesetomato As System.Windows.Forms.Button
    Friend WithEvents btnMargherita As System.Windows.Forms.Button
    Friend WithEvents btnDesserts As System.Windows.Forms.Button
    Friend WithEvents btnDrinks As System.Windows.Forms.Button
    Friend WithEvents btnBurgerSalads As System.Windows.Forms.Button
    Friend WithEvents btnSeafood As System.Windows.Forms.Button
    Friend WithEvents btnTandooriexpress As System.Windows.Forms.Button
    Friend WithEvents btnVegetarianhot As System.Windows.Forms.Button
    Friend WithEvents btnBeefeater As System.Windows.Forms.Button
    Friend WithEvents btnAmericanhot As System.Windows.Forms.Button
    Friend WithEvents btnMeatfeast As System.Windows.Forms.Button
    Friend WithEvents btnMediterraneanspecial As System.Windows.Forms.Button
    Friend WithEvents panStarters As System.Windows.Forms.Panel
    Friend WithEvents btnGarlicmushroombread As System.Windows.Forms.Button
    Friend WithEvents btnChickenspringroll As System.Windows.Forms.Button
    Friend WithEvents btnBBQchickenwings As System.Windows.Forms.Button
    Friend WithEvents btnVegetarianspringrolls As System.Windows.Forms.Button
    Friend WithEvents btnSpicychickenwings As System.Windows.Forms.Button
    Friend WithEvents btnChickennuggets As System.Windows.Forms.Button
    Friend WithEvents btnChips As System.Windows.Forms.Button
    Friend WithEvents btnPotatowedges As System.Windows.Forms.Button
    Friend WithEvents btnOnionrings As System.Windows.Forms.Button
    Friend WithEvents btnGarlicbread As System.Windows.Forms.Button
    Friend WithEvents panDesserts As System.Windows.Forms.Panel
    Friend WithEvents bntChokiesCream As System.Windows.Forms.Button
    Friend WithEvents btnPineapplefritter As System.Windows.Forms.Button
    Friend WithEvents btnBelgianchocolate As System.Windows.Forms.Button
    Friend WithEvents btnBananafritter As System.Windows.Forms.Button
    Friend WithEvents btnStrawberry As System.Windows.Forms.Button
    Friend WithEvents btnStrawberrycake As System.Windows.Forms.Button
    Friend WithEvents btnHaaganDazs As System.Windows.Forms.Button
    Friend WithEvents btnVanilla As System.Windows.Forms.Button
    Friend WithEvents btnTennesseecake As System.Windows.Forms.Button
    Friend WithEvents btnChocolateCake As System.Windows.Forms.Button
    Friend WithEvents panDrinks As System.Windows.Forms.Panel
    Friend WithEvents btnCans As System.Windows.Forms.Button
    Friend WithEvents btnPureapplejuice As System.Windows.Forms.Button
    Friend WithEvents btnPureorangejuice As System.Windows.Forms.Button
    Friend WithEvents btnChocolate As System.Windows.Forms.Button
    Friend WithEvents btnCappuccino As System.Windows.Forms.Button
    Friend WithEvents btnRegulartea As System.Windows.Forms.Button
    Friend WithEvents btnBottle As System.Windows.Forms.Button
    Friend WithEvents btnRegularcoffe As System.Windows.Forms.Button
    Friend WithEvents panBurgerSalad As System.Windows.Forms.Panel
    Friend WithEvents btnMixedgreen As System.Windows.Forms.Button
    Friend WithEvents btnChickenburger As System.Windows.Forms.Button
    Friend WithEvents btnFishburger As System.Windows.Forms.Button
    Friend WithEvents btnVegetableburger As System.Windows.Forms.Button
    Friend WithEvents btnQuarterpounder As System.Windows.Forms.Button
    Friend WithEvents btnHumus As System.Windows.Forms.Button
    Friend WithEvents btnFreshsalad As System.Windows.Forms.Button
    Friend WithEvents btnColeslaw As System.Windows.Forms.Button
    Friend WithEvents panSize As System.Windows.Forms.Panel
    Friend WithEvents btn15XL As System.Windows.Forms.Button
    Friend WithEvents btn9M As System.Windows.Forms.Button
    Friend WithEvents btn12L As System.Windows.Forms.Button
    Friend WithEvents btn18XXL As System.Windows.Forms.Button
    Friend WithEvents btnCoke As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents btnPepsi As System.Windows.Forms.Button
    Friend WithEvents btnFanta As System.Windows.Forms.Button
    Friend WithEvents panCans As System.Windows.Forms.Panel
    Friend WithEvents panBottle As System.Windows.Forms.Panel
    Friend WithEvents btnBtlPepsi As System.Windows.Forms.Button
    Friend WithEvents btnBtlCoke As System.Windows.Forms.Button
    Friend WithEvents btnBtlFanta As System.Windows.Forms.Button
    Friend WithEvents lstQuantity As System.Windows.Forms.ListBox
    Friend WithEvents lstSize As System.Windows.Forms.ListBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lstItemName As System.Windows.Forms.ListBox
    Friend WithEvents lstTotalPrice As System.Windows.Forms.ListBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblTP As System.Windows.Forms.Label
    Friend WithEvents lblST As System.Windows.Forms.Label
    Friend WithEvents lblVAT As System.Windows.Forms.Label
    Friend WithEvents lblGT As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents btnOrder As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LandscapeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColourToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HowToToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CallAssistanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VersionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PortraitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents panQuantity As System.Windows.Forms.Panel
    Friend WithEvents txtQuantity As System.Windows.Forms.TextBox
    Friend WithEvents btnDone As System.Windows.Forms.Button
    Friend WithEvents btn9 As System.Windows.Forms.Button
    Friend WithEvents btn8 As System.Windows.Forms.Button
    Friend WithEvents btn7 As System.Windows.Forms.Button
    Friend WithEvents btn6 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn5 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn4 As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn0 As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label

End Class
